<?php 

trait InstagramActions{
	
	
}