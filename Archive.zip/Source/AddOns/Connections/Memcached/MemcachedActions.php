<?php

trait MemcachedActions{


}