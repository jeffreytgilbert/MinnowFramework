<?php

// this one needs to have the sessions config stored in the config (which should extend model) and then call its settings from within if using db as the config

final class HybridAuthHelper extends Helper{

	public function __construct(Model $Config){
		// run parent construct action to save settings
		parent::__construct($Config);
		
		Run::fromHelpers('HybridAuth/Requirements/Hybrid/Auth.php');
		Run::fromHelpers('HybridAuth/Requirements/HybridAuthAbstraction.php');
		
		$SettingsObject = $this->getConfig();
		
		$settings_array = $SettingsObject->toArray();
		
		$config = array();
		
		$HybridAuthConfig = $settings_array['HybridAuth'];
		unset($settings_array['HybridAuth']);
		
		foreach($settings_array as $key => $value){
			$enabled = $value['enabled'];
			unset($value['enabled']);
			$HybridAuthConfig[$key] = array(
				'enabled' => $enabled,
				'keys' => $value
			);
		}
		pr($HybridAuthConfig);
			
		die;
		
		$this->_instance = new HybridAuthAbstraction( $config );
	}

	public function getInstance(){
		if($this->_instance instanceof HybridAuthAbstraction) return $this->_instance;
		return new HybridAuthAbstraction();
	}

	public function __destruct(){
		// unset($this);
	}
}
