<?php

class DataCollection extends ModelCollection{
}